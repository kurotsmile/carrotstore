<?php
echo '<ul id="menu">';
echo '<li><a href="index.php?func=login">Login</a></li>';
echo '<li><a href="index.php?func=register">Register</a></li>';
echo '<li><a href="users.php">All User</a></li>';
echo '</ul>'
?>